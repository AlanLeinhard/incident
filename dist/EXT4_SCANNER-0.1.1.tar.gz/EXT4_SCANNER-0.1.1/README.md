sudo apt-get install python3-pyqt5
sudo apt-get install qtcreator pyqt5-dev-tools
sudo apt-get install qttools5-dev-tools

<!-- 
pyuic5 -x script2.ui -o script2.py

diskpart
list disk
exit


C:\Users\Alan\Documents\work\incident\env\Scripts\pyuic5.exe -x script.ui -o script.py -->